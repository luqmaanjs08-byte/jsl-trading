// EASY EDIT: Change the product names and descriptions below.
// Save the file, then upload the updated files to GitHub Pages.

const products = [
  { name: "Automotive Parts", description: "Quality parts for a wide range of vehicles." },
  { name: "Car Accessories", description: "Practical and stylish accessories for your vehicle." },
  { name: "LED Lighting", description: "Headlights, fog lamps and automotive lighting solutions." },
  { name: "Trading Products", description: "Reliable products sourced with customer needs in mind." }
];
