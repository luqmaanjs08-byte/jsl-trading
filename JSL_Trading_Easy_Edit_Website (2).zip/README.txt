# JSL Trading Website

## Easy editing
The website is designed so basic product changes can be made without changing the main HTML.

Open `products.js` and edit:
- Product names
- Product descriptions

Your contact details are already included in `index.html`.

## Put it online with GitHub Pages
1. Create a free account at GitHub.
2. Create a new repository named `jsl-trading`.
3. Upload `index.html`, `products.js`, and `logo.png`.
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, select **Deploy from a branch**.
6. Select the `main` branch and `/ (root)`, then save.
7. GitHub will give you your live website address.

When you edit a file and upload the new version, the live website updates automatically.
